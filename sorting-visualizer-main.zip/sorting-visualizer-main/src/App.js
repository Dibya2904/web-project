import '../src/App.css';
import Algorithms from '../src/Components/Algorithms';
import Header from './Components/Header';

export default function App(){
  return (
    <div className='App'>
      <Header/>
      <Algorithms/>
    </div>
  );
}